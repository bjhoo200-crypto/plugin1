package kr.example.cannon;

import io.papermc.paper.entity.TeleportFlag;
import io.papermc.paper.event.player.PrePlayerAttackEntityEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Input;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.entity.Shulker;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.event.world.EntitiesUnloadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static kr.example.cannon.ShipManager.Part;
import static kr.example.cannon.ShipManager.box;

/**
 * 기차: 조종칸(기관차) / 화물칸 / 탑승칸(객차) + 철로 타일.
 * - 철로: 5x5 타일. 아무 블럭 윗면에나 설치. 옆 타일과 자동 연결(직선/곡선), 웅크리고 설치하면 갈림길(T자)
 * - 기차는 철로를 따라 자동으로 달림. 운전자가 W 로 출발시키면 연료가 있는 동안 계속 달림(S = 정지)
 * - 갈림길: 타일을 우클릭해서 방향 전환(초록/빨강 표시) 또는 지나가기 직전 A/D 로 선택
 * 칸 좌표계: 칸 중심(레일 윗면) 기준, +Z = 앞, +X = 왼쪽, +Y = 위
 */
public final class TrainManager implements Listener {

    static final double SPACING = 6.4;    // 칸 중심 사이 거리
    static final float FLOOR = 0.5f;      // 바닥 윗면 높이 (레일 윗면 기준)
    static final double SEAT_UP = 0.16;
    static final int CRATES = 16;
    static final double TILE = 5.0;       // 타일 한 변
    static final double TILE_TOP = 0.2;   // 타일(레일) 윗면 높이

    // 방향: 0=북(-Z) 1=동(+X) 2=남(+Z) 3=서(-X)
    static final int[] DX = {0, 1, 0, -1};
    static final int[] DZ = {-1, 0, 1, 0};
    static final String[] DNAME = {"북", "동", "남", "서"};

    // =====================================================================
    //  칸 종류 정의
    // =====================================================================
    /** pads 원소: {x, z, 크기, 종류(0=바닥, 1=벽)} */
    record CarType(String key, String label, Material icon, float[][] seats, float[][] pads,
                   boolean loco, boolean cargo, List<Part> parts) {}

    static void chair(List<Part> o, float x, float z, String mat) {
        o.add(box(mat, x, FLOOR + 0.07f, z, 0.8f, 0.14f, 0.8f));
        o.add(box(mat, x, FLOOR + 0.35f, z - 0.4f, 0.8f, 0.5f, 0.1f));
    }

    static void chassis(List<Part> o, String floorMat) {
        o.add(box("minecraft:black_concrete", 0f, 0.2f, 0f, 4.4f, 0.2f, 5.6f));
        o.add(box(floorMat, 0f, 0.4f, 0f, 5.0f, 0.2f, 6.0f));
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                o.add(box("minecraft:black_concrete", sx * 1.7f, 0.1f, sz * 2.0f, 0.5f, 0.2f, 1.4f));
            }
        }
        for (int sz = -1; sz <= 1; sz += 2) {
            o.add(box("minecraft:iron_block", 0f, 0.35f, sz * 3.2f, 0.3f, 0.3f, 0.5f));
        }
    }

    static void floorPads(List<float[]> o, boolean cabOnly) {
        if (cabOnly) {
            o.add(new float[]{-1.25f, -1.9f, 2.5f, 0});
            o.add(new float[]{1.25f, -1.9f, 2.5f, 0});
            o.add(new float[]{-1.25f, -0.6f, 2.5f, 0});
            o.add(new float[]{1.25f, -0.6f, 2.5f, 0});
        } else {
            for (float z : new float[]{-2f, 0f, 2f}) {
                o.add(new float[]{-1.25f, z, 2.5f, 0});
                o.add(new float[]{1.25f, z, 2.5f, 0});
            }
        }
    }

    /** 옆벽: 안쪽 면이 x=±2.3 에 오도록 바깥쪽으로 붙인 투명 충돌 상자 */
    static void sideWalls(List<float[]> o, float[] zs, float size) {
        for (int sd = -1; sd <= 1; sd += 2) {
            for (float z : zs) o.add(new float[]{sd * (2.3f + size / 2f), z, size, 1});
        }
    }

    /** 끝벽 모서리(가운데 문은 비워 둠) */
    static void endCorners(List<float[]> o, int sz) {
        for (int sd = -1; sd <= 1; sd += 2) o.add(new float[]{sd * 1.75f, sz * 3.65f, 1.5f, 1});
    }

    static CarType passType() {
        List<Part> p = new ArrayList<>();
        chassis(p, "minecraft:gray_concrete");
        p.add(box("minecraft:red_concrete", 0f, FLOOR + 0.01f, 0f, 1.0f, 0.02f, 5.6f));
        for (int sd = -1; sd <= 1; sd += 2) {
            float x = sd * 2.4f;
            p.add(box("minecraft:blue_concrete", x, FLOOR + 0.45f, 0f, 0.2f, 0.9f, 6.0f));
            p.add(box("minecraft:light_blue_stained_glass", x, FLOOR + 1.35f, 0f, 0.1f, 0.9f, 6.0f));
            p.add(box("minecraft:white_concrete", x, FLOOR + 1.9f, 0f, 0.24f, 0.2f, 6.0f));
            for (float z : new float[]{-2.9f, -1f, 1f, 2.9f}) {
                p.add(box("minecraft:blue_concrete", x, FLOOR + 1.35f, z, 0.22f, 0.9f, 0.2f));
            }
        }
        for (int sz = -1; sz <= 1; sz += 2) {
            for (int sd = -1; sd <= 1; sd += 2) {
                p.add(box("minecraft:blue_concrete", sd * 1.75f, FLOOR + 1.0f, sz * 2.9f, 1.5f, 2.0f, 0.2f));
            }
            p.add(box("minecraft:blue_concrete", 0f, FLOOR + 1.9f, sz * 2.9f, 2.0f, 0.2f, 0.2f));
        }
        p.add(box("minecraft:white_concrete", 0f, FLOOR + 2.075f, 0f, 5.0f, 0.15f, 6.0f));
        for (float z : new float[]{-1.5f, 1.5f}) {
            p.add(box("minecraft:sea_lantern", 0f, FLOOR + 1.95f, z, 0.4f, 0.1f, 0.4f));
        }
        float[][] seats = {{-1f, 2f}, {1f, 2f}, {-1f, 0f}, {1f, 0f}, {-1f, -2f}, {1f, -2f}};
        for (float[] s : seats) chair(p, s[0], s[1], "minecraft:gray_concrete");
        List<float[]> pd = new ArrayList<>();
        floorPads(pd, false);
        sideWalls(pd, new float[]{-2f, 0f, 2f}, 2.0f);
        endCorners(pd, -1);
        endCorners(pd, 1);
        return new CarType("pass", "탑승칸", Material.MINECART, seats, pd.toArray(new float[0][]),
                false, false, List.copyOf(p));
    }

    static CarType cargoType() {
        List<Part> p = new ArrayList<>();
        chassis(p, "minecraft:brown_concrete");
        for (int sd = -1; sd <= 1; sd += 2) {
            p.add(box("minecraft:brown_concrete", sd * 2.4f, FLOOR + 0.6f, 0f, 0.2f, 1.2f, 6.0f));
            p.add(box("minecraft:orange_concrete", sd * 2.4f, FLOOR + 1.25f, 0f, 0.26f, 0.1f, 6.0f));
        }
        for (int sz = -1; sz <= 1; sz += 2) {
            p.add(box("minecraft:brown_concrete", 0f, FLOOR + 0.6f, sz * 2.9f, 5.0f, 1.2f, 0.2f));
            p.add(box("minecraft:orange_concrete", 0f, FLOOR + 1.25f, sz * 2.9f, 5.0f, 0.1f, 0.26f));
        }
        List<float[]> pd = new ArrayList<>();
        floorPads(pd, false);
        sideWalls(pd, new float[]{-2.25f, -0.75f, 0.75f, 2.25f}, 1.5f);
        for (int sz = -1; sz <= 1; sz += 2) {
            for (float x : new float[]{-1.5f, 0f, 1.5f}) pd.add(new float[]{x, sz * 3.65f, 1.5f, 1});
        }
        return new CarType("cargo", "화물칸", Material.CHEST_MINECART, new float[0][], pd.toArray(new float[0][]),
                false, true, List.copyOf(p));
    }

    static CarType locoType() {
        List<Part> p = new ArrayList<>();
        chassis(p, "minecraft:gray_concrete");
        p.add(box("minecraft:red_concrete", 0f, FLOOR + 0.9f, 1.9f, 3.6f, 1.8f, 2.4f));
        p.add(box("minecraft:black_concrete", 0f, FLOOR + 1.85f, 1.9f, 3.2f, 0.1f, 2.2f));
        p.add(box("minecraft:black_concrete", 0f, FLOOR + 2.3f, 2.4f, 0.6f, 0.8f, 0.6f));
        p.add(box("minecraft:iron_block", 0f, 0.6f, 3.3f, 3.0f, 0.5f, 0.4f));
        p.add(box("minecraft:sea_lantern", 0f, FLOOR + 1.4f, 3.15f, 0.5f, 0.4f, 0.1f));
        p.add(box("minecraft:furnace[facing=north,lit=false]", 0f, FLOOR + 0.5f, 0.6f, 0.9f, 0.9f, 0.5f));
        for (int sd = -1; sd <= 1; sd += 2) {
            float x = sd * 2.4f;
            p.add(box("minecraft:red_concrete", x, FLOOR + 0.45f, -1.15f, 0.2f, 0.9f, 3.7f));
            p.add(box("minecraft:light_blue_stained_glass", x, FLOOR + 1.35f, -1.15f, 0.1f, 0.9f, 3.7f));
            p.add(box("minecraft:black_concrete", x, FLOOR + 1.9f, -1.15f, 0.24f, 0.2f, 3.7f));
        }
        for (int sd = -1; sd <= 1; sd += 2) {
            p.add(box("minecraft:red_concrete", sd * 1.75f, FLOOR + 1.0f, -2.9f, 1.5f, 2.0f, 0.2f));
        }
        p.add(box("minecraft:red_concrete", 0f, FLOOR + 1.9f, -2.9f, 2.0f, 0.2f, 0.2f));
        p.add(box("minecraft:black_concrete", 0f, FLOOR + 2.075f, -1.1f, 5.2f, 0.15f, 3.9f));
        p.add(box("minecraft:black_concrete", 0f, FLOOR + 0.45f, -0.25f, 1.4f, 0.9f, 0.5f));
        p.add(box("minecraft:redstone_lamp[lit=true]", 0f, FLOOR + 1.0f, -0.25f, 0.4f, 0.2f, 0.4f));
        chair(p, 0f, -1.2f, "minecraft:black_concrete");
        float[][] seats = {{0f, -1.2f}};
        List<float[]> pd = new ArrayList<>();
        floorPads(pd, true);
        sideWalls(pd, new float[]{-2.0f, -0.3f}, 2.0f);
        endCorners(pd, -1);
        for (float z : new float[]{1.6f, 2.2f}) {
            for (float x : new float[]{-0.9f, 0.9f}) pd.add(new float[]{x, z, 1.8f, 1});
        }
        return new CarType("loco", "조종칸", Material.FURNACE_MINECART, seats, pd.toArray(new float[0][]),
                true, false, List.copyOf(p));
    }

    // =====================================================================
    //  철로 경로 기하
    // =====================================================================
    static double pathLen(int a, int b) {
        return ((a + 2) % 4 == b) ? TILE : Math.PI * TILE / 4.0;
    }

    static boolean isCurve(int a, int b) {
        return (a + 2) % 4 != b;
    }

    /** 타일 중심 기준 경로 위치: {dx, dz, yaw(도)} */
    static double[] pathPos(int a, int b, double s) {
        double h = TILE / 2.0;
        double ax = DX[a] * h, az = DZ[a] * h;
        double bx = DX[b] * h, bz = DZ[b] * h;
        double px, pz, dx, dz;
        if ((a + 2) % 4 == b) {
            double t = s / TILE;
            px = ax + (bx - ax) * t;
            pz = az + (bz - az) * t;
            dx = bx - ax;
            dz = bz - az;
        } else {
            double cx = ax + bx, cz = az + bz;       // 곡선 중심(타일 모서리)
            double ux = -bx / h, uz = -bz / h;       // 중심 -> a
            double vx = -ax / h, vz = -az / h;       // 중심 -> b
            double th = s / h;
            px = cx + h * (Math.cos(th) * ux + Math.sin(th) * vx);
            pz = cz + h * (Math.cos(th) * uz + Math.sin(th) * vz);
            dx = -Math.sin(th) * ux + Math.cos(th) * vx;
            dz = -Math.sin(th) * uz + Math.cos(th) * vz;
        }
        double yaw = Math.toDegrees(Math.atan2(-dx, dz));
        return new double[]{px, pz, yaw};
    }

    // =====================================================================
    //  철로 타일
    // =====================================================================
    final class Tile {
        final World world;
        final int tx, tz, y;
        int links;       // 연결된 방향 비트
        int axis;        // 연결이 없을 때 방향 (0=남북, 1=동서)
        int state;       // 갈림길 전환 상태
        String bed;      // 바닥 블럭 데이터
        Interaction hit;
        final List<BlockDisplay> shown = new ArrayList<>();

        Tile(World world, int tx, int tz, int y, String bed) {
            this.world = world;
            this.tx = tx;
            this.tz = tz;
            this.y = y;
            this.bed = bed;
        }

        double cx() {
            return tx * TILE + TILE / 2.0;
        }

        double cz() {
            return tz * TILE + TILE / 2.0;
        }

        int linkCount() {
            return Integer.bitCount(links);
        }

        boolean has(int d) {
            return (links & (1 << d)) != 0;
        }

        int[] exits() {
            int n = linkCount();
            if (n == 0) return new int[]{axis, axis + 2};
            if (n == 1) {
                int d = Integer.numberOfTrailingZeros(links);
                return new int[]{d, (d + 2) % 4};
            }
            int[] r = new int[n];
            int k = 0;
            for (int d = 0; d < 4; d++) if (has(d)) r[k++] = d;
            return r;
        }

        boolean accepts(int edge) {
            for (int e : exits()) if (e == edge) return true;
            return false;
        }

        String key() {
            return tileKey(world, tx, tz);
        }

        void save() {
            PersistentDataContainer p = hit.getPersistentDataContainer();
            p.set(K_TILE, PersistentDataType.INTEGER_ARRAY, new int[]{tx, tz, y, links, axis, state});
            p.set(K_TBED, PersistentDataType.STRING, bed);
        }

        void clearVisual() {
            for (BlockDisplay d : shown) d.remove();
            shown.clear();
            for (Entity en : hit.getNearbyEntities(4, 3, 4)) {
                if (en instanceof BlockDisplay && key().equals(en.getPersistentDataContainer().get(K_TID, PersistentDataType.STRING))) {
                    en.remove();
                }
            }
        }

        void addPart(Part pt) {
            Location base = new Location(world, cx(), y, cz());
            BlockDisplay d = world.spawn(base, BlockDisplay.class, e -> {
                e.setBlock(Bukkit.createBlockData(pt.data()));
                e.setTransformation(ShipManager.transformOf(pt));
                e.setViewRange(2.0f);
                e.getPersistentDataContainer().set(K_TID, PersistentDataType.STRING, key());
            });
            shown.add(d);
        }

        /** 연결 상태에 맞게 모양을 다시 그림 */
        void rebuild() {
            clearVisual();
            addPart(box(bed, 0f, 0.05f, 0f, 4.96f, 0.1f, 4.96f));
            for (int[] pr : pairs()) drawPath(pr[0], pr[1]);
            if (linkCount() == 3) {
                addPart(box(state == 0 ? "minecraft:lime_concrete" : "minecraft:red_concrete", 0f, 0.25f, 0f, 0.4f, 0.1f, 0.4f));
            }
            save();
        }

        List<int[]> pairs() {
            List<int[]> r = new ArrayList<>();
            int[] ex = exits();
            if (ex.length <= 2) {
                r.add(new int[]{ex[0], ex[1]});
            } else {
                int stem = -1;
                for (int d : ex) if (!has((d + 2) % 4)) stem = d;
                List<Integer> col = new ArrayList<>();
                for (int d : ex) if (d != stem) col.add(d);
                r.add(new int[]{col.get(0), col.get(1)});
                r.add(new int[]{stem, col.get(0)});
                r.add(new int[]{stem, col.get(1)});
            }
            return r;
        }

        void drawPath(int a, int b) {
            double len = pathLen(a, b);
            int seg = isCurve(a, b) ? 8 : 1;
            for (int side = -1; side <= 1; side += 2) {
                for (int i = 0; i < seg; i++) {
                    double[] p0 = railPoint(a, b, len * i / seg, side * 1.7);
                    double[] p1 = railPoint(a, b, len * (i + 1) / seg, side * 1.7);
                    double dx = p1[0] - p0[0], dz = p1[1] - p0[1];
                    double l = Math.hypot(dx, dz);
                    addPart(new Part("minecraft:iron_block", (float) ((p0[0] + p1[0]) / 2), 0.16f,
                            (float) ((p0[1] + p1[1]) / 2), 0.16f, 0.08f, (float) (l + 0.06),
                            (float) Math.atan2(dx, dz), 0f));
                }
            }
            for (int i = 0; i < 5; i++) {
                double s = len * (i + 0.5) / 5.0;
                double[] c = pathPos(a, b, s);
                addPart(new Part("minecraft:spruce_planks", (float) c[0], 0.13f, (float) c[1], 3.9f, 0.06f, 0.3f,
                        (float) Math.toRadians(-c[2]), 0f));
            }
        }

        double[] railPoint(int a, int b, double s, double off) {
            double[] c = pathPos(a, b, s);
            double yawRad = Math.toRadians(c[2]);
            // 진행 방향 (-sin, cos), 왼쪽 = (cos, sin)
            return new double[]{c[0] + Math.cos(yawRad) * off, c[1] + Math.sin(yawRad) * off};
        }
    }

    // =====================================================================
    //  필드
    // =====================================================================
    final CannonPlugin plugin;
    final Map<String, CarType> types = new LinkedHashMap<>();
    final Map<UUID, Car> cars = new HashMap<>();
    final Map<String, Tile> tiles = new HashMap<>();
    final Map<UUID, Long> lastPlace = new HashMap<>();
    long tickCount = 0;

    double maxSpeed = 0.45, curveSpeed = 0.2, accel = 0.008, brake = 0.03;
    double coalSeconds = 80, oilSeconds = 120;
    String defaultBed = "minecraft:gravel";

    NamespacedKey K_ID, K_ROLE, K_IDX, K_TYPE, K_YAW, K_NEXT, K_ITEM, K_BURN, K_FUEL, K_C0, K_C1, K_RUN;
    NamespacedKey K_TILE, K_TBED, K_TID;

    TrainManager(CannonPlugin plugin) {
        this.plugin = plugin;
    }

    void enable() {
        K_ID = new NamespacedKey(plugin, "train_id");
        K_ROLE = new NamespacedKey(plugin, "train_role");
        K_IDX = new NamespacedKey(plugin, "train_idx");
        K_TYPE = new NamespacedKey(plugin, "train_type");
        K_YAW = new NamespacedKey(plugin, "train_yaw");
        K_NEXT = new NamespacedKey(plugin, "train_next");
        K_ITEM = new NamespacedKey(plugin, "train_item");
        K_BURN = new NamespacedKey(plugin, "train_burn");
        K_FUEL = new NamespacedKey(plugin, "train_fuelinv");
        K_C0 = new NamespacedKey(plugin, "train_cargo_0");
        K_C1 = new NamespacedKey(plugin, "train_cargo_1");
        K_RUN = new NamespacedKey(plugin, "train_run");
        K_TILE = new NamespacedKey(plugin, "track_tile");
        K_TBED = new NamespacedKey(plugin, "track_bed");
        K_TID = new NamespacedKey(plugin, "track_tid");

        types.put("loco", locoType());
        types.put("cargo", cargoType());
        types.put("pass", passType());

        var c = plugin.getConfig();
        maxSpeed = c.getDouble("train.max-speed", 0.45);
        curveSpeed = c.getDouble("train.curve-speed", 0.2);
        accel = c.getDouble("train.accel", 0.008);
        brake = c.getDouble("train.brake", 0.03);
        coalSeconds = c.getDouble("train.coal-seconds", 80);
        oilSeconds = c.getDouble("train.oil-seconds", 120);
        Material bed = Material.matchMaterial(c.getString("train.track-bed", "GRAVEL"));
        if (bed != null && bed.isBlock()) defaultBed = bed.createBlockData().getAsString();

        Bukkit.getPluginManager().registerEvents(this, plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
        for (World w : Bukkit.getWorlds()) {
            for (Interaction hb : w.getEntitiesByClass(Interaction.class)) {
                tryRegisterTile(hb);
                tryRegister(hb, 0);
            }
        }
    }

    void disable() {
        for (Car c : cars.values()) c.saveState();
        cars.clear();
        tiles.clear();
    }

    // =====================================================================
    //  유틸
    // =====================================================================
    void tag(Entity en, String cid, String role, int idx) {
        PersistentDataContainer p = en.getPersistentDataContainer();
        p.set(K_ID, PersistentDataType.STRING, cid);
        p.set(K_ROLE, PersistentDataType.STRING, role);
        p.set(K_IDX, PersistentDataType.INTEGER, idx);
    }

    String role(Entity en) {
        return en.getPersistentDataContainer().get(K_ROLE, PersistentDataType.STRING);
    }

    int idxOf(Entity en) {
        Integer i = en.getPersistentDataContainer().get(K_IDX, PersistentDataType.INTEGER);
        return i == null ? 0 : i;
    }

    boolean isTrainEntity(Entity en) {
        return en.getPersistentDataContainer().has(K_ID, PersistentDataType.STRING);
    }

    boolean isTileHit(Entity en) {
        return en.getPersistentDataContainer().has(K_TILE, PersistentDataType.INTEGER_ARRAY);
    }

    Car carOf(Entity en) {
        String sid = en.getPersistentDataContainer().get(K_ID, PersistentDataType.STRING);
        if (sid == null) return null;
        try {
            return cars.get(UUID.fromString(sid));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    static double[] rot(double yaw, double lx, double lz) {
        double rad = Math.toRadians(yaw);
        double cs = Math.cos(rad);
        double sn = Math.sin(rad);
        return new double[]{lx * cs - lz * sn, lx * sn + lz * cs};
    }

    static boolean passable(Block b) {
        return b.isPassable() || b.getType() == Material.LILY_PAD;
    }

    static String tileKey(World w, int tx, int tz) {
        return w.getUID() + ":" + tx + ":" + tz;
    }

    Tile tileAt(World w, int tx, int tz) {
        return tiles.get(tileKey(w, tx, tz));
    }

    Tile tileAtPos(World w, double x, double z) {
        return tileAt(w, (int) Math.floor(x / TILE), (int) Math.floor(z / TILE));
    }

    // ---- 연료 ----
    double burnSeconds(ItemStack it) {
        if (it == null || it.getType().isAir()) return 0;
        Material m = it.getType();
        if (m == Material.COAL || m == Material.CHARCOAL) return coalSeconds;
        if (m == Material.COAL_BLOCK) return coalSeconds * 10;
        if (plugin.is(it, plugin.oilItem)) return oilSeconds;
        return 0;
    }

    boolean isFuel(ItemStack it) {
        return burnSeconds(it) > 0;
    }

    // ---- 아이템 ----
    ItemStack carItem(CarType t) {
        ItemStack it = new ItemStack(t.icon());
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text(t.label(), NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
        String desc = t.loco() ? "기차를 끄는 조종칸 (석탄/정제유)" : t.cargo() ? "짐을 싣는 화물칸" : "6명이 앉는 탑승칸";
        m.lore(List.of(
                Component.text(desc, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("철로 위에서 우클릭으로 설치", NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("다른 칸 앞/뒤에 놓으면 자동으로 연결", NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)));
        m.getPersistentDataContainer().set(K_ITEM, PersistentDataType.STRING, t.key());
        m.setMaxStackSize(1);
        it.setItemMeta(m);
        return it;
    }

    ItemStack trackItem(String bedData, int amount) {
        ItemStack it = new ItemStack(Material.RAIL, amount);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text("철로 (5x5)", NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                Component.text("블럭 윗면에 우클릭: 5x5 철로 설치, 옆 철로와 자동 연결(직선/곡선)", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("웅크리고 설치: 이미 이어진 철로에도 연결 -> 갈림길(T자)", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("갈림길 우클릭: 방향 전환 / 웅크리고 때리기: 회수", NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)));
        m.getPersistentDataContainer().set(K_ITEM, PersistentDataType.STRING, "track");
        m.getPersistentDataContainer().set(K_TBED, PersistentDataType.STRING, bedData);
        it.setItemMeta(m);
        return it;
    }

    String itemKey(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(K_ITEM, PersistentDataType.STRING);
    }

    // ---- 인벤토리 홀더 ----
    static final class FuelHolder implements InventoryHolder {
        final UUID carId;
        Inventory inv;

        FuelHolder(UUID carId) {
            this.carId = carId;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    static final class CargoHolder implements InventoryHolder {
        final UUID carId;
        final int idx;
        Inventory inv;

        CargoHolder(UUID carId, int idx) {
            this.carId = carId;
            this.idx = idx;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    // =====================================================================
    //  칸 객체
    // =====================================================================
    final class Car {
        final UUID id;
        final CarType type;
        final Interaction hull;
        final ArmorStand[] seats;
        final Interaction[] seatHits;
        final Interaction[] hits;
        final ArmorStand[] padCars;
        final Shulker[] pads;
        final double[] padDy;
        final List<BlockDisplay> parts;
        final BlockDisplay[] crates;
        final Inventory fuelInv;
        final Inventory[] cargo;
        final World world;
        double x, y, z;
        float yaw;
        UUID nextId = null;
        // 머리 칸 전용
        double speed = 0;
        double dist = 0;
        double burn = 0;
        boolean running = false;
        String sig = null;
        final List<double[]> trail = new ArrayList<>();
        Tile cur;
        int pin, pout;
        double ps;
        boolean located = false;
        boolean inLeft, inRight;
        boolean warned = false, dirty = false;

        Car(UUID id, CarType type, Interaction hull, ArmorStand[] seats, Interaction[] seatHits, Interaction[] hits,
            ArmorStand[] padCars, Shulker[] pads, List<BlockDisplay> parts, BlockDisplay[] crates,
            double x, double y, double z, float yaw) {
            this.id = id;
            this.type = type;
            this.hull = hull;
            this.seats = seats;
            this.seatHits = seatHits;
            this.hits = hits;
            this.padCars = padCars;
            this.pads = pads;
            this.padDy = new double[pads.length];
            this.parts = parts;
            this.crates = crates;
            this.world = hull.getWorld();
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
            if (type.loco()) {
                FuelHolder h = new FuelHolder(id);
                h.inv = Bukkit.createInventory(h, InventoryType.FURNACE, Component.text("조종칸 연료", NamedTextColor.DARK_GRAY));
                fuelInv = h.inv;
            } else {
                fuelInv = null;
            }
            if (type.cargo()) {
                cargo = new Inventory[2];
                for (int i = 0; i < 2; i++) {
                    CargoHolder h = new CargoHolder(id, i);
                    h.inv = Bukkit.createInventory(h, 54, Component.text("화물칸 " + (i + 1) + "/2", NamedTextColor.DARK_GRAY));
                    cargo[i] = h.inv;
                }
            } else {
                cargo = new Inventory[0];
            }
        }

        Location origin() {
            return new Location(world, x, y, z, yaw, 0f);
        }

        Player rider(int i) {
            for (Entity en : seats[i].getPassengers()) if (en instanceof Player pl) return pl;
            return null;
        }

        boolean hasRider() {
            for (int i = 0; i < seats.length; i++) if (rider(i) != null) return true;
            return false;
        }

        boolean isRider(Player p) {
            for (ArmorStand st : seats) if (st.getPassengers().contains(p)) return true;
            return false;
        }

        boolean cargoEmpty() {
            for (Inventory inv : cargo) {
                for (ItemStack it : inv.getContents()) if (it != null && !it.getType().isAir()) return false;
            }
            return true;
        }

        // ---- 저장 ----
        void saveState() {
            PersistentDataContainer p = hull.getPersistentDataContainer();
            p.set(K_YAW, PersistentDataType.FLOAT, yaw);
            if (nextId == null) p.remove(K_NEXT);
            else p.set(K_NEXT, PersistentDataType.STRING, nextId.toString());
            p.set(K_BURN, PersistentDataType.DOUBLE, burn);
            p.set(K_RUN, PersistentDataType.BYTE, (byte) (running ? 1 : 0));
            if (fuelInv != null) {
                p.set(K_FUEL, PersistentDataType.BYTE_ARRAY, ItemStack.serializeItemsAsBytes(fuelInv.getContents()));
            }
            saveCargo();
        }

        void saveCargo() {
            PersistentDataContainer p = hull.getPersistentDataContainer();
            if (cargo.length == 2) {
                p.set(K_C0, PersistentDataType.BYTE_ARRAY, ItemStack.serializeItemsAsBytes(cargo[0].getContents()));
                p.set(K_C1, PersistentDataType.BYTE_ARRAY, ItemStack.serializeItemsAsBytes(cargo[1].getContents()));
            }
        }

        void loadState() {
            PersistentDataContainer p = hull.getPersistentDataContainer();
            try {
                byte[] f = p.get(K_FUEL, PersistentDataType.BYTE_ARRAY);
                if (fuelInv != null && f != null && f.length > 0) fuelInv.setContents(ItemStack.deserializeItemsFromBytes(f));
                if (cargo.length == 2) {
                    byte[] a = p.get(K_C0, PersistentDataType.BYTE_ARRAY);
                    byte[] b = p.get(K_C1, PersistentDataType.BYTE_ARRAY);
                    if (a != null && a.length > 0) cargo[0].setContents(ItemStack.deserializeItemsFromBytes(a));
                    if (b != null && b.length > 0) cargo[1].setContents(ItemStack.deserializeItemsFromBytes(b));
                }
            } catch (Exception ex) {
                plugin.getLogger().warning("기차 내용물 복구 실패: " + ex.getMessage());
            }
            Double bv = p.get(K_BURN, PersistentDataType.DOUBLE);
            burn = bv == null ? 0 : bv;
            Byte rv = p.get(K_RUN, PersistentDataType.BYTE);
            running = rv != null && rv == 1;
            String ns = p.get(K_NEXT, PersistentDataType.STRING);
            if (ns != null) {
                try {
                    nextId = UUID.fromString(ns);
                } catch (IllegalArgumentException ignored) {
                    nextId = null;
                }
            }
        }

        // ---- 화물 표시 ----
        void updateCrates() {
            if (crates.length == 0) return;
            List<ItemStack> stacks = new ArrayList<>();
            for (Inventory inv : cargo) {
                for (ItemStack it : inv.getContents()) if (it != null && !it.getType().isAir()) stacks.add(it);
            }
            int n = 0;
            if (!stacks.isEmpty()) {
                n = (int) Math.ceil(stacks.size() / 108.0 * CRATES);
                n = Math.max(1, Math.min(CRATES, n));
            }
            for (int i = 0; i < crates.length; i++) {
                BlockDisplay d = crates[i];
                if (d == null || !d.isValid()) continue;
                if (i < n) {
                    ItemStack s = stacks.get(Math.min(stacks.size() - 1, i * stacks.size() / n));
                    Material m = s.getType();
                    boolean solid = m.isBlock() && m.isSolid() && m.isOccluding();
                    d.setBlock(solid ? m.createBlockData() : Bukkit.createBlockData("minecraft:barrel[facing=up]"));
                } else {
                    d.setBlock(Bukkit.createBlockData(Material.AIR));
                }
            }
        }

        // ---- 탑승 ----
        void mount(Player p, int want) {
            if (p.isInsideVehicle()) return;
            if (seats.length == 0) return;
            int idx = want;
            if (idx < 0) {
                for (int i = 0; i < seats.length; i++) {
                    if (rider(i) == null) {
                        idx = i;
                        break;
                    }
                }
            }
            if (idx < 0 || idx >= seats.length) {
                p.sendActionBar(Component.text("빈 자리가 없습니다.", NamedTextColor.RED));
                return;
            }
            if (rider(idx) != null) {
                p.sendActionBar(Component.text("이미 누군가 앉아 있습니다.", NamedTextColor.RED));
                return;
            }
            seats[idx].addPassenger(p);
            if (type.loco()) p.sendActionBar(Component.text("운전석 - W 출발(이후 자동 주행) / S 정지 / 갈림길 직전 A,D 선택", NamedTextColor.GOLD));
        }

        // ---- 이동 ----
        double padBottom(int i) {
            float[] pd = type.pads()[i];
            return y + FLOOR - (pd[3] > 0.5f ? 0 : pd[2]) - padDy[i];
        }

        void moveAll() {
            Location base = new Location(world, x, y, z, yaw, 0f);
            hull.teleport(new Location(world, x, y, z, yaw, 0f));
            for (int i = 0; i < seats.length; i++) {
                double[] o = rot(yaw, type.seats()[i][0], type.seats()[i][1]);
                seats[i].teleport(new Location(world, x + o[0], y + FLOOR + SEAT_UP, z + o[1], yaw, 0f),
                        TeleportFlag.EntityState.RETAIN_PASSENGERS);
                seatHits[i].teleport(new Location(world, x + o[0], y + FLOOR, z + o[1]));
            }
            for (int i = 0; i < hits.length; i++) {
                double[] o = type.loco() ? rot(yaw, 0, 1.9) : rot(yaw, i == 0 ? -1.25 : 1.25, 0);
                hits[i].teleport(new Location(world, x + o[0], y + FLOOR, z + o[1]));
            }
            for (int i = 0; i < pads.length; i++) {
                double[] o = rot(yaw, type.pads()[i][0], type.pads()[i][1]);
                padCars[i].teleport(new Location(world, x + o[0], padBottom(i), z + o[1], yaw, 0f),
                        TeleportFlag.EntityState.RETAIN_PASSENGERS);
            }
            for (BlockDisplay d : parts) d.teleport(base);
            for (BlockDisplay d : crates) if (d != null) d.teleport(base);
        }

        void calibrate() {
            for (int i = 0; i < pads.length; i++) {
                if (!pads[i].isValid() || !padCars[i].isValid()) continue;
                double d = pads[i].getY() - padCars[i].getY();
                if (Math.abs(d) < 4.0) padDy[i] = d;
            }
            moveAll();
        }

        void carry(double ox, double oz, float oyaw) {
            double orad = Math.toRadians(oyaw);
            double oc = Math.cos(orad);
            double os = Math.sin(orad);
            double nrad = Math.toRadians(yaw);
            double nc = Math.cos(nrad);
            double ns = Math.sin(nrad);
            double deckY = y + FLOOR;
            for (Player pl : world.getNearbyPlayers(new Location(world, ox, y, oz), 6.0)) {
                if (pl.isInsideVehicle() || !pl.isOnGround()) continue;
                Location pp = pl.getLocation();
                double dy = pp.getY() - deckY;
                if (dy < -0.6 || dy > 0.9) continue;
                double wx = pp.getX() - ox;
                double wz = pp.getZ() - oz;
                double lx = wx * oc + wz * os;
                double lz = -wx * os + wz * oc;
                if (Math.abs(lx) > 2.8 || Math.abs(lz) > 3.2) continue;
                if (pl.getCurrentInput().isJump()) continue;
                double nx = x + lx * nc - lz * ns;
                double nz = z + lx * ns + lz * nc;
                pl.setVelocity(new Vector(nx - pp.getX(), 0.0, nz - pp.getZ()));
            }
        }

        void remove() {
            for (ArmorStand st : seats) {
                for (Entity en : new ArrayList<>(st.getPassengers())) st.removePassenger(en);
                st.remove();
            }
            for (Interaction i : seatHits) i.remove();
            for (Interaction i : hits) i.remove();
            for (Shulker sk : pads) sk.remove();
            for (ArmorStand pc : padCars) {
                for (Entity en : new ArrayList<>(pc.getPassengers())) pc.removePassenger(en);
                pc.remove();
            }
            for (BlockDisplay d : parts) d.remove();
            for (BlockDisplay d : crates) if (d != null) d.remove();
            hull.remove();
        }

        // ---- 연료 ----
        boolean ignite() {
            if (fuelInv == null) return false;
            ItemStack s = fuelInv.getItem(1);
            double sec = burnSeconds(s);
            if (sec <= 0) return false;
            s.setAmount(s.getAmount() - 1);
            fuelInv.setItem(1, s.getAmount() <= 0 ? null : s);
            burn = sec * 20;
            dirty = true;
            world.playSound(origin(), Sound.BLOCK_FURNACE_FIRE_CRACKLE, 1f, 1f);
            return true;
        }

        int fuelItems() {
            if (fuelInv == null) return 0;
            ItemStack s = fuelInv.getItem(1);
            return s == null ? 0 : s.getAmount();
        }

        // ---- 궤적(뒤 칸들이 따라오는 길) ----
        void rebuildTrail(List<Car> chain) {
            trail.clear();
            dist = 0;
            located = false;
            for (int k = chain.size() - 1; k >= 0; k--) {
                Car c = chain.get(k);
                trail.add(new double[]{-k * SPACING, c.x, c.y, c.z, c.yaw});
            }
        }

        double[] sample(double d) {
            if (trail.isEmpty()) return new double[]{x, y, z, yaw};
            double[] first = trail.get(0);
            if (d <= first[0]) return new double[]{first[1], first[2], first[3], first[4]};
            for (int i = 1; i < trail.size(); i++) {
                double[] a = trail.get(i - 1);
                double[] b = trail.get(i);
                if (d <= b[0]) {
                    double span = b[0] - a[0];
                    double t = span <= 1e-9 ? 1 : (d - a[0]) / span;
                    double dy = ((b[4] - a[4]) % 360 + 540) % 360 - 180;
                    return new double[]{a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t,
                            a[3] + (b[3] - a[3]) * t, a[4] + dy * t};
                }
            }
            double[] last = trail.get(trail.size() - 1);
            return new double[]{last[1], last[2], last[3], last[4]};
        }

        // ---- 철로 위 위치 ----
        /** 현재 위치에서 가장 가까운 철로 경로를 찾아 그 위에 올림 */
        boolean locate() {
            Tile t = tileAtPos(world, x, z);
            if (t == null || Math.abs(t.y + TILE_TOP - y) > 0.6) return false;
            int[] ex = t.exits();
            double bestScore = Double.MAX_VALUE;
            int ba = -1, bb = -1;
            double bs = 0;
            for (int a : ex) {
                for (int b : ex) {
                    if (a == b) continue;
                    double len = pathLen(a, b);
                    for (int k = 0; k <= 12; k++) {
                        double s = len * k / 12.0;
                        double[] p = pathPos(a, b, s);
                        double d = Math.hypot(t.cx() + p[0] - x, t.cz() + p[1] - z);
                        double dyaw = Math.abs(((p[2] - yaw) % 360 + 540) % 360 - 180);
                        double score = d + 0.03 * dyaw;
                        if (score < bestScore) {
                            bestScore = score;
                            ba = a;
                            bb = b;
                            bs = s;
                        }
                    }
                }
            }
            if (ba < 0) return false;
            cur = t;
            pin = ba;
            pout = bb;
            ps = bs;
            located = true;
            return true;
        }

        int chooseExit(Tile t, int ein) {
            List<Integer> ex = new ArrayList<>();
            for (int e : t.exits()) if (e != ein) ex.add(e);
            if (ex.isEmpty()) return -1;
            if (ex.size() == 1) return ex.get(0);
            int d = (ein + 2) % 4;
            int left = (d + 3) % 4;
            int right = (d + 1) % 4;
            if (inLeft && !inRight && ex.contains(left)) return left;
            if (inRight && !inLeft && ex.contains(right)) return right;
            if (ex.contains(d)) {
                if (t.state == 0) return d;
                return ex.get(0) == d ? ex.get(1) : ex.get(0);
            }
            return t.state == 0 ? left : right;
        }

        void halt(boolean stopRunning) {
            speed = 0;
            if (stopRunning && running) {
                running = false;
                dirty = true;
            }
        }

        /** 다음 타일로 넘어감. 못 넘어가면 false */
        boolean enterNext() {
            int e = pout;
            int nx = cur.tx + DX[e];
            int nz = cur.tz + DZ[e];
            Tile n = tileAt(world, nx, nz);
            if (n == null) {
                boolean loaded = world.isChunkLoaded(Math.floorDiv((int) (nx * TILE + 2), 16), Math.floorDiv((int) (nz * TILE + 2), 16));
                halt(loaded);
                return false;
            }
            int ein = (e + 2) % 4;
            if (n.y != cur.y || !n.accepts(ein)) {
                halt(true);
                return false;
            }
            int ex = chooseExit(n, ein);
            if (ex < 0) {
                halt(true);
                return false;
            }
            cur = n;
            pin = ein;
            pout = ex;
            ps = 0;
            return true;
        }

        double advance(double ds) {
            double moved = 0;
            int guard = 0;
            while (ds > 1e-9 && guard++ < 6) {
                double len = pathLen(pin, pout);
                double rem = len - ps;
                if (ds < rem) {
                    ps += ds;
                    moved += ds;
                    ds = 0;
                } else {
                    ds -= rem;
                    moved += rem;
                    ps = len;
                    if (!enterNext()) break;
                }
            }
            return moved;
        }

        void driveHead(List<Car> chain) {
            Player drv = type.loco() ? rider(0) : null;
            boolean fwd = false, back = false;
            inLeft = false;
            inRight = false;
            if (drv != null) {
                Input in = drv.getCurrentInput();
                fwd = in.isForward();
                back = in.isBackward();
                inLeft = in.isLeft();
                inRight = in.isRight();
                if (fwd && !back && !running) {
                    running = true;
                    dirty = true;
                } else if (back && running) {
                    running = false;
                    dirty = true;
                }
            }
            if (!type.loco()) return;
            if (!located && !locate()) {
                speed = 0;
                if (drv != null && tickCount % 40 == 0) {
                    drv.sendActionBar(Component.text("철로 위가 아닙니다.", NamedTextColor.RED));
                }
                return;
            }
            boolean throttle = running;
            if (throttle && burn <= 0 && !ignite()) {
                throttle = false;
                running = false;
                dirty = true;
                Location l = origin();
                world.playSound(l, Sound.BLOCK_FIRE_EXTINGUISH, 1f, 1f);
                for (Player pl : world.getNearbyPlayers(l, 20)) {
                    pl.sendActionBar(Component.text("연료가 떨어졌습니다! 조종칸 앞쪽 화로에 석탄/정제유를 넣으세요.", NamedTextColor.RED));
                }
            }
            double cap = isCurve(pin, pout) ? Math.min(curveSpeed, maxSpeed) : maxSpeed;
            if (throttle) {
                burn -= 1;
                dirty = true;
                if (speed < cap) speed = Math.min(cap, speed + accel);
                else speed = Math.max(cap, speed - 0.01);
            } else if (back) {
                speed = Math.max(0, speed - brake);
            } else {
                speed = Math.max(0, speed * 0.99 - 0.003);
            }
            if (speed < 0.003) speed = 0;

            if (drv != null && tickCount % 10 == 0) {
                NamedTextColor col = burn <= 0 && fuelItems() == 0 ? NamedTextColor.RED : NamedTextColor.GOLD;
                drv.sendActionBar(Component.text((running ? "주행 중" : "정지") + "  |  " + (int) Math.round(speed * 72)
                        + " km/h  |  연료 " + (int) Math.ceil(burn / 20) + "초 + 대기 " + fuelItems() + "개  |  " + chain.size() + "칸", col));
            }

            if (speed == 0) {
                if (dirty) {
                    saveState();
                    dirty = false;
                }
                return;
            }

            double moved = advance(speed);
            if (moved <= 0) return;
            double[] pp = pathPos(pin, pout, ps);

            int n = chain.size();
            double[] ox = new double[n], oz = new double[n];
            float[] oy = new float[n];
            for (int i = 0; i < n; i++) {
                ox[i] = chain.get(i).x;
                oz[i] = chain.get(i).z;
                oy[i] = chain.get(i).yaw;
            }
            dist += moved;
            x = cur.cx() + pp[0];
            z = cur.cz() + pp[1];
            y = cur.y + TILE_TOP;
            yaw = (float) pp[2];
            trail.add(new double[]{dist, x, y, z, yaw});
            double keep = dist - (n - 1) * SPACING - 2;
            while (trail.size() > 2 && trail.get(1)[0] < keep) trail.remove(0);
            moveAll();
            carry(ox[0], oz[0], oy[0]);
            for (int i = 1; i < n; i++) {
                Car c = chain.get(i);
                double[] s = sample(dist - i * SPACING);
                c.x = s[0];
                c.y = s[1];
                c.z = s[2];
                c.yaw = (float) s[3];
                c.moveAll();
                c.carry(ox[i], oz[i], oy[i]);
            }
            dirty = true;
        }
    }

    // =====================================================================
    //  칸 생성 / 복구
    // =====================================================================
    Car spawnCar(CarType t, Location at, float yaw) {
        UUID id = UUID.randomUUID();
        String cid = id.toString();
        World w = at.getWorld();
        double x = at.getX(), y = at.getY(), z = at.getZ();
        Location base = new Location(w, x, y, z, yaw, 0f);

        Interaction hull = w.spawn(base, Interaction.class, ent -> {
            ent.setInteractionWidth(5f);
            ent.setInteractionHeight(0.5f);
            ent.setResponsive(true);
            tag(ent, cid, "hull", 0);
            ent.getPersistentDataContainer().set(K_TYPE, PersistentDataType.STRING, t.key());
            ent.getPersistentDataContainer().set(K_YAW, PersistentDataType.FLOAT, yaw);
        });

        int ns = t.seats().length;
        ArmorStand[] seats = new ArmorStand[ns];
        Interaction[] seatHits = new Interaction[ns];
        for (int i = 0; i < ns; i++) {
            final int idx = i;
            double[] o = rot(yaw, t.seats()[i][0], t.seats()[i][1]);
            seats[i] = w.spawn(new Location(w, x + o[0], y + FLOOR + SEAT_UP, z + o[1], yaw, 0f), ArmorStand.class, a -> {
                a.setVisible(false);
                a.setGravity(false);
                a.setMarker(true);
                a.setSmall(true);
                a.setInvulnerable(true);
                a.setSilent(true);
                tag(a, cid, "seat", idx);
            });
            seatHits[i] = w.spawn(new Location(w, x + o[0], y + FLOOR, z + o[1]), Interaction.class, h -> {
                h.setInteractionWidth(0.9f);
                h.setInteractionHeight(1.3f);
                h.setResponsive(true);
                tag(h, cid, "seathit", idx);
            });
        }

        int nh = t.loco() ? 1 : t.cargo() ? 2 : 0;
        Interaction[] hits = new Interaction[nh];
        for (int i = 0; i < nh; i++) {
            final int idx = i;
            double[] o = t.loco() ? rot(yaw, 0, 1.9) : rot(yaw, i == 0 ? -1.25 : 1.25, 0);
            hits[i] = w.spawn(new Location(w, x + o[0], y + FLOOR, z + o[1]), Interaction.class, h -> {
                h.setInteractionWidth(t.loco() ? 3.6f : 2.4f);
                h.setInteractionHeight(t.loco() ? 1.8f : 1.6f);
                h.setResponsive(true);
                tag(h, cid, t.loco() ? "fuelhit" : "cargohit", idx);
            });
        }

        int np = t.pads().length;
        ArmorStand[] padCars = new ArmorStand[np];
        Shulker[] pads = new Shulker[np];
        for (int i = 0; i < np; i++) {
            final int idx = i;
            final float sc = t.pads()[i][2];
            final boolean wall = t.pads()[i][3] > 0.5f;
            double[] o = rot(yaw, t.pads()[i][0], t.pads()[i][1]);
            double py = y + FLOOR - (wall ? 0 : sc);
            padCars[i] = w.spawn(new Location(w, x + o[0], py, z + o[1], yaw, 0f), ArmorStand.class, a -> {
                a.setVisible(false);
                a.setGravity(false);
                a.setMarker(true);
                a.setSmall(true);
                a.setInvulnerable(true);
                a.setSilent(true);
                tag(a, cid, "padcar", idx);
            });
            pads[i] = w.spawn(new Location(w, x + o[0], py, z + o[1], yaw, 0f), Shulker.class, sk -> {
                sk.setAI(false);
                sk.setInvisible(true);
                sk.setSilent(true);
                sk.setInvulnerable(true);
                sk.setGravity(false);
                sk.setPeek(0f);
                sk.setRemoveWhenFarAway(false);
                Attribute attr = Registry.ATTRIBUTE.get(NamespacedKey.minecraft("scale"));
                AttributeInstance ai = attr == null ? null : sk.getAttribute(attr);
                if (ai != null) ai.setBaseValue(sc);
                tag(sk, cid, "pad", idx);
            });
            padCars[i].addPassenger(pads[i]);
        }

        List<BlockDisplay> parts = new ArrayList<>();
        for (int i = 0; i < t.parts().size(); i++) {
            final Part pt = t.parts().get(i);
            final int idx = i;
            parts.add(w.spawn(base, BlockDisplay.class, d -> {
                d.setBlock(Bukkit.createBlockData(pt.data()));
                d.setTransformation(ShipManager.transformOf(pt));
                d.setTeleportDuration(3);
                d.setViewRange(2.0f);
                tag(d, cid, "part", idx);
            }));
        }

        BlockDisplay[] crates = new BlockDisplay[t.cargo() ? CRATES : 0];
        for (int i = 0; i < crates.length; i++) {
            final int idx = i;
            int layer = i / 8;
            int k = i % 8;
            float cx = (k % 2 == 0 ? -0.95f : 0.95f);
            float cz = -2.1f + (k / 2) * 1.4f;
            float cy = FLOOR + 0.65f + layer * 1.3f;
            final Part pt = box("minecraft:air", cx, cy, cz, 1.3f, 1.3f, 1.3f);
            crates[i] = w.spawn(base, BlockDisplay.class, d -> {
                d.setBlock(Bukkit.createBlockData(Material.AIR));
                d.setTransformation(ShipManager.transformOf(pt));
                d.setTeleportDuration(3);
                d.setViewRange(2.0f);
                tag(d, cid, "crate", idx);
            });
        }

        Car car = new Car(id, t, hull, seats, seatHits, hits, padCars, pads, parts, crates, x, y, z, yaw);
        cars.put(id, car);
        car.saveState();
        Bukkit.getScheduler().runTaskLater(plugin, car::calibrate, 3L);
        return car;
    }

    void tryRegister(Interaction hb, int attempt) {
        if (!hb.isValid()) return;
        PersistentDataContainer hp = hb.getPersistentDataContainer();
        if (!"hull".equals(hp.get(K_ROLE, PersistentDataType.STRING))) return;
        String cid = hp.get(K_ID, PersistentDataType.STRING);
        String tk = hp.get(K_TYPE, PersistentDataType.STRING);
        if (cid == null || tk == null) return;
        CarType t = types.get(tk);
        if (t == null) return;
        UUID id;
        try {
            id = UUID.fromString(cid);
        } catch (IllegalArgumentException ex) {
            return;
        }
        if (cars.containsKey(id)) return;

        ArmorStand[] seats = new ArmorStand[t.seats().length];
        Interaction[] seatHits = new Interaction[t.seats().length];
        Interaction[] hits = new Interaction[t.loco() ? 1 : t.cargo() ? 2 : 0];
        ArmorStand[] padCars = new ArmorStand[t.pads().length];
        Shulker[] pads = new Shulker[t.pads().length];
        List<BlockDisplay> parts = new ArrayList<>();
        BlockDisplay[] crates = new BlockDisplay[t.cargo() ? CRATES : 0];
        for (Entity en : hb.getNearbyEntities(9, 8, 9)) {
            PersistentDataContainer p = en.getPersistentDataContainer();
            if (!cid.equals(p.get(K_ID, PersistentDataType.STRING))) continue;
            String role = p.get(K_ROLE, PersistentDataType.STRING);
            if (role == null) continue;
            int idx = idxOf(en);
            switch (role) {
                case "seat" -> {
                    if (en instanceof ArmorStand a && idx >= 0 && idx < seats.length) seats[idx] = a;
                }
                case "seathit" -> {
                    if (en instanceof Interaction h && idx >= 0 && idx < seatHits.length) seatHits[idx] = h;
                }
                case "fuelhit", "cargohit" -> {
                    if (en instanceof Interaction h && idx >= 0 && idx < hits.length) hits[idx] = h;
                }
                case "padcar" -> {
                    if (en instanceof ArmorStand a && idx >= 0 && idx < padCars.length) padCars[idx] = a;
                }
                case "pad" -> {
                    if (en instanceof Shulker sk && idx >= 0 && idx < pads.length) pads[idx] = sk;
                }
                case "part" -> {
                    if (en instanceof BlockDisplay d) parts.add(d);
                }
                case "crate" -> {
                    if (en instanceof BlockDisplay d && idx >= 0 && idx < crates.length) crates[idx] = d;
                }
                default -> {
                }
            }
        }
        boolean complete = parts.size() == t.parts().size();
        for (ArmorStand a : seats) if (a == null) complete = false;
        for (Interaction h : seatHits) if (h == null) complete = false;
        for (Interaction h : hits) if (h == null) complete = false;
        for (ArmorStand a : padCars) if (a == null) complete = false;
        for (Shulker sk : pads) if (sk == null) complete = false;
        for (BlockDisplay d : crates) if (d == null) complete = false;
        if (!complete) {
            if (attempt < 5) {
                final int next = attempt + 1;
                Bukkit.getScheduler().runTaskLater(plugin, () -> tryRegister(hb, next), 20L);
            }
            return;
        }
        Float sy = hp.get(K_YAW, PersistentDataType.FLOAT);
        float yaw = sy == null ? hb.getLocation().getYaw() : sy;
        Car car = new Car(id, t, hb, seats, seatHits, hits, padCars, pads, parts, crates,
                hb.getX(), hb.getY(), hb.getZ(), yaw);
        car.loadState();
        cars.put(id, car);
        car.moveAll();
        car.updateCrates();
        Bukkit.getScheduler().runTaskLater(plugin, car::calibrate, 3L);
    }

    void tryRegisterTile(Interaction hb) {
        if (!hb.isValid()) return;
        PersistentDataContainer p = hb.getPersistentDataContainer();
        int[] v = p.get(K_TILE, PersistentDataType.INTEGER_ARRAY);
        if (v == null || v.length < 6) return;
        String bed = p.get(K_TBED, PersistentDataType.STRING);
        Tile t = new Tile(hb.getWorld(), v[0], v[1], v[2], bed == null ? defaultBed : bed);
        t.links = v[3];
        t.axis = v[4];
        t.state = v[5];
        t.hit = hb;
        if (tiles.containsKey(t.key())) return;
        tiles.put(t.key(), t);
        t.rebuild();
    }

    // =====================================================================
    //  틱
    // =====================================================================
    List<Car> chainFrom(Car head) {
        List<Car> l = new ArrayList<>();
        Set<UUID> seen = new HashSet<>();
        Car c = head;
        while (c != null && seen.add(c.id)) {
            l.add(c);
            c = c.nextId == null ? null : cars.get(c.nextId);
        }
        return l;
    }

    void tick() {
        tickCount++;
        Iterator<Car> it = cars.values().iterator();
        Set<UUID> hasPrev = new HashSet<>();
        while (it.hasNext()) {
            Car c = it.next();
            if (!c.hull.isValid()) {
                it.remove();
                continue;
            }
            if (c.nextId != null && cars.containsKey(c.nextId)) hasPrev.add(c.nextId);
        }
        for (Car c : new ArrayList<>(cars.values())) {
            if (hasPrev.contains(c.id)) {
                c.sig = null;
                continue;
            }
            try {
                List<Car> chain = chainFrom(c);
                StringBuilder sb = new StringBuilder();
                for (Car k : chain) sb.append(k.id).append(',');
                String sig = sb.toString();
                if (!sig.equals(c.sig)) {
                    c.rebuildTrail(chain);
                    c.sig = sig;
                }
                c.driveHead(chain);
            } catch (Exception ex) {
                if (!c.warned) {
                    c.warned = true;
                    plugin.getLogger().warning("기차 처리 중 오류: " + ex);
                }
            }
        }
    }

    // =====================================================================
    //  설치
    // =====================================================================
    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (itemKey(item) == null) return;
        e.setCancelled(true);
        tryPlace(e.getPlayer(), item);
    }

    void tryPlace(Player p, ItemStack item) {
        Long last = lastPlace.get(p.getUniqueId());
        if (last != null && last == tickCount) return;
        lastPlace.put(p.getUniqueId(), tickCount);
        String key = itemKey(item);
        if (key == null) return;
        if (key.equals("track")) {
            placeTrack(p, item);
            return;
        }
        CarType t = types.get(key);
        if (t != null) placeCar(p, item, t);
    }

    void placeTrack(Player p, ItemStack item) {
        RayTraceResult r = p.rayTraceBlocks(8.0);
        Block b = r == null ? null : r.getHitBlock();
        if (b == null || r.getHitBlockFace() != BlockFace.UP) {
            p.sendActionBar(Component.text("블럭의 윗면을 바라보고 사용하세요.", NamedTextColor.RED));
            return;
        }
        World w = b.getWorld();
        int tx = Math.floorDiv(b.getX(), 5);
        int tz = Math.floorDiv(b.getZ(), 5);
        int y = b.getY() + 1;
        if (tileAt(w, tx, tz) != null) {
            p.sendActionBar(Component.text("이미 철로가 있습니다.", NamedTextColor.RED));
            return;
        }
        for (int dx = 0; dx < 5; dx++) {
            for (int dz = 0; dz < 5; dz++) {
                for (int dy = 0; dy < 3; dy++) {
                    if (!passable(w.getBlockAt(tx * 5 + dx, y + dy, tz * 5 + dz))) {
                        p.sendActionBar(Component.text("5x5 칸 위가 비어 있어야 합니다. (높이 3칸) 막힌 곳: "
                                + (tx * 5 + dx) + ", " + (y + dy) + ", " + (tz * 5 + dz), NamedTextColor.RED));
                        return;
                    }
                }
            }
        }
        boolean junction = p.isSneaking();
        String bed = item.getItemMeta().getPersistentDataContainer().get(K_TBED, PersistentDataType.STRING);
        if (bed == null) bed = defaultBed;
        final String bedF = bed;
        double cxw = tx * TILE + TILE / 2.0;
        double czw = tz * TILE + TILE / 2.0;
        Tile t = new Tile(w, tx, tz, y, bedF);
        t.hit = w.spawn(new Location(w, cxw, y, czw), Interaction.class, ent -> {
            ent.setInteractionWidth(4.6f);
            ent.setInteractionHeight(0.25f);
            ent.setResponsive(true);
        });
        double yawRad = Math.toRadians(p.getLocation().getYaw());
        t.axis = Math.abs(Math.sin(yawRad)) > Math.abs(Math.cos(yawRad)) ? 1 : 0;

        List<Integer> cand = new ArrayList<>();
        int maxMine = junction ? 3 : 2;
        for (int d = 0; d < 4; d++) {
            Tile n = tileAt(w, tx + DX[d], tz + DZ[d]);
            if (n != null && n.y == y && n.linkCount() < maxMine) cand.add(d);
        }
        List<Integer> use = new ArrayList<>();
        if (cand.size() > maxMine) {
            boolean paired = false;
            for (int d : cand) {
                if (cand.contains((d + 2) % 4) && !paired) {
                    use.add(d);
                    use.add((d + 2) % 4);
                    paired = true;
                }
            }
            if (!paired) use.addAll(cand.subList(0, maxMine));
            while (use.size() > maxMine) use.remove(use.size() - 1);
        } else {
            use.addAll(cand);
        }
        for (int d : use) {
            Tile n = tileAt(w, tx + DX[d], tz + DZ[d]);
            t.links |= 1 << d;
            n.links |= 1 << ((d + 2) % 4);
            n.rebuild();
        }
        tiles.put(t.key(), t);
        t.rebuild();
        w.playSound(new Location(w, cxw, y, czw), Sound.BLOCK_GRAVEL_PLACE, 1f, 0.8f);
        if (p.getGameMode() != GameMode.CREATIVE) item.setAmount(item.getAmount() - 1);
        if (t.linkCount() == 3) {
            p.sendActionBar(Component.text("갈림길이 만들어졌습니다. 철로를 우클릭하면 방향이 바뀝니다.", NamedTextColor.GREEN));
        }
    }

    void placeCar(Player p, ItemStack item, CarType t) {
        RayTraceResult r = p.rayTraceBlocks(8.0);
        Block b = r == null ? null : r.getHitBlock();
        Tile tile = null;
        if (b != null) tile = tileAt(b.getWorld(), Math.floorDiv(b.getX(), 5), Math.floorDiv(b.getZ(), 5));
        if (tile == null) {
            p.sendActionBar(Component.text("철로(5x5) 위를 바라보고 사용하세요.", NamedTextColor.RED));
            return;
        }
        World w = tile.world;
        // 플레이어 시선과 가장 가까운 방향의 경로 위, 타일 한가운데에 놓음
        double yawP = p.getLocation().getYaw();
        double bestD = Double.MAX_VALUE;
        double[] bestPos = null;
        for (int a : tile.exits()) {
            for (int bb : tile.exits()) {
                if (a == bb) continue;
                double[] pp = pathPos(a, bb, pathLen(a, bb) / 2.0);
                double dyaw = Math.abs(((pp[2] - yawP) % 360 + 540) % 360 - 180);
                if (dyaw < bestD) {
                    bestD = dyaw;
                    bestPos = pp;
                }
            }
        }
        if (bestPos == null) return;
        double x = tile.cx() + bestPos[0];
        double z = tile.cz() + bestPos[1];
        double y = tile.y + TILE_TOP;
        float yaw = (float) bestPos[2];

        Car prevCar = null;
        Car nextCar = null;
        double bd = 3.5;
        for (Car o : cars.values()) {
            if (o.world != w || Math.abs(o.y - y) > 0.5) continue;
            double rad = Math.toRadians(o.yaw);
            double fx = -Math.sin(rad) * SPACING;
            double fz = Math.cos(rad) * SPACING;
            double yd = Math.abs(((yaw - o.yaw) % 360 + 540) % 360 - 180);
            if (yd > 60) continue;
            if (o.nextId == null) {
                double d = Math.hypot(x - (o.x - fx), z - (o.z - fz));
                if (d < bd) {
                    bd = d;
                    prevCar = o;
                    nextCar = null;
                }
            }
            boolean oHasPrev = false;
            for (Car q : cars.values()) if (o.id.equals(q.nextId)) oHasPrev = true;
            if (!oHasPrev) {
                double d = Math.hypot(x - (o.x + fx), z - (o.z + fz));
                if (d < bd) {
                    bd = d;
                    nextCar = o;
                    prevCar = null;
                }
            }
        }
        if (prevCar != null) {
            double rad = Math.toRadians(prevCar.yaw);
            double sx = prevCar.x + Math.sin(rad) * SPACING;
            double sz = prevCar.z - Math.cos(rad) * SPACING;
            Tile st = tileAtPos(w, sx, sz);
            if (st != null && st.y == tile.y) {
                x = sx;
                z = sz;
                yaw = prevCar.yaw;
            } else {
                prevCar = null;
            }
        } else if (nextCar != null) {
            double rad = Math.toRadians(nextCar.yaw);
            double sx = nextCar.x - Math.sin(rad) * SPACING;
            double sz = nextCar.z + Math.cos(rad) * SPACING;
            Tile st = tileAtPos(w, sx, sz);
            if (st != null && st.y == tile.y) {
                x = sx;
                z = sz;
                yaw = nextCar.yaw;
            } else {
                nextCar = null;
            }
        }
        Car car = spawnCar(t, new Location(w, x, y, z), yaw);
        if (prevCar != null) {
            prevCar.nextId = car.id;
            prevCar.saveState();
        }
        if (nextCar != null) car.nextId = nextCar.id;
        car.saveState();
        w.playSound(car.origin(), Sound.BLOCK_ANVIL_PLACE, 1f, 1.2f);
        if (prevCar != null || nextCar != null) p.sendActionBar(Component.text("다른 칸과 연결되었습니다.", NamedTextColor.GREEN));
        if (p.getGameMode() != GameMode.CREATIVE) item.setAmount(item.getAmount() - 1);
    }

    // =====================================================================
    //  클릭 / 회수
    // =====================================================================
    @EventHandler
    public void onClick(PlayerInteractEntityEvent e) {
        Entity en = e.getRightClicked();
        boolean tileHit = isTileHit(en);
        if (!tileHit && !isTrainEntity(en)) return;
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();

        ItemStack held = p.getInventory().getItemInMainHand();
        if (itemKey(held) != null) {
            tryPlace(p, held);
            return;
        }

        if (tileHit) {
            int[] v = en.getPersistentDataContainer().get(K_TILE, PersistentDataType.INTEGER_ARRAY);
            Tile t = v == null ? null : tileAt(en.getWorld(), v[0], v[1]);
            if (t == null) return;
            if (t.linkCount() == 3) {
                t.state ^= 1;
                t.rebuild();
                p.sendActionBar(Component.text(t.state == 0
                        ? "갈림길: 초록 - 직진 (줄기 쪽에서 들어오면 왼쪽)"
                        : "갈림길: 빨강 - 꺾임 (줄기 쪽에서 들어오면 오른쪽)", t.state == 0 ? NamedTextColor.GREEN : NamedTextColor.RED));
            } else {
                p.sendActionBar(Component.text("연결 " + t.linkCount() + "개 - 갈림길이 아닙니다.", NamedTextColor.GRAY));
            }
            return;
        }

        Car c = carOf(en);
        if (c == null) return;
        String role = role(en);
        int idx = idxOf(en);
        if (role == null) return;

        if (p.isSneaking() && held.getType().isAir()) {
            if (c.nextId == null) {
                p.sendActionBar(Component.text("이 칸 뒤에 연결된 칸이 없습니다.", NamedTextColor.YELLOW));
            } else {
                c.nextId = null;
                c.saveState();
                c.sig = null;
                p.sendActionBar(Component.text("뒤쪽 칸과 분리했습니다.", NamedTextColor.GREEN));
                c.world.playSound(c.origin(), Sound.BLOCK_PISTON_EXTEND, 1f, 1.3f);
            }
            return;
        }
        switch (role) {
            case "fuelhit" -> p.openInventory(c.fuelInv);
            case "cargohit" -> {
                if (idx >= 0 && idx < c.cargo.length) p.openInventory(c.cargo[idx]);
            }
            case "seathit" -> c.mount(p, idx);
            case "hull" -> {
                if (c.type.loco()) c.mount(p, 0);
                else if (c.seats.length > 0) c.mount(p, -1);
            }
            default -> {
            }
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        Entity en = e.getEntity();
        if (!isTrainEntity(en) && !isTileHit(en)) return;
        e.setCancelled(true);
        if (e instanceof EntityDamageByEntityEvent d && d.getDamager() instanceof Player p) punched(p, en);
    }

    @EventHandler
    public void onPreAttack(PrePlayerAttackEntityEvent e) {
        if (!isTrainEntity(e.getAttacked()) && !isTileHit(e.getAttacked())) return;
        e.setCancelled(true);
        punched(e.getPlayer(), e.getAttacked());
    }

    void punched(Player p, Entity en) {
        if (isTileHit(en)) pickupTile(p, en);
        else tryPickup(p, en);
    }

    void pickupTile(Player p, Entity en) {
        int[] v = en.getPersistentDataContainer().get(K_TILE, PersistentDataType.INTEGER_ARRAY);
        Tile t = v == null ? null : tileAt(en.getWorld(), v[0], v[1]);
        if (t == null) return;
        if (!p.isSneaking()) {
            p.sendActionBar(Component.text("웅크린 채로 때리면 철로를 회수합니다.", NamedTextColor.YELLOW));
            return;
        }
        for (int d = 0; d < 4; d++) {
            if (!t.has(d)) continue;
            Tile n = tileAt(t.world, t.tx + DX[d], t.tz + DZ[d]);
            if (n != null) {
                n.links &= ~(1 << ((d + 2) % 4));
                n.rebuild();
            }
        }
        t.clearVisual();
        tiles.remove(t.key());
        Location l = new Location(t.world, t.cx(), t.y + 0.5, t.cz());
        t.hit.remove();
        t.world.dropItemNaturally(l, trackItem(t.bed, 1));
    }

    void tryPickup(Player p, Entity en) {
        Car c = carOf(en);
        if (c == null) return;
        if (c.hasRider()) {
            if (!c.isRider(p)) p.sendActionBar(Component.text("누군가 타고 있어서 회수할 수 없습니다.", NamedTextColor.RED));
            return;
        }
        if (!p.isSneaking()) {
            p.sendActionBar(Component.text("웅크린 채로 때리면 회수합니다.", NamedTextColor.YELLOW));
            return;
        }
        if (!c.cargoEmpty()) {
            p.sendActionBar(Component.text("화물을 모두 비워야 회수할 수 있습니다.", NamedTextColor.RED));
            return;
        }
        Location l = c.origin().add(0, 1, 0);
        if (c.fuelInv != null) {
            for (ItemStack it : c.fuelInv.getContents()) {
                if (it != null && !it.getType().isAir()) l.getWorld().dropItemNaturally(l, it);
            }
            c.fuelInv.clear();
        }
        detach(c);
        l.getWorld().dropItemNaturally(l, carItem(c.type));
        c.remove();
        cars.remove(c.id);
    }

    void detach(Car c) {
        for (Car o : cars.values()) {
            if (c.id.equals(o.nextId)) {
                o.nextId = null;
                o.saveState();
            }
        }
    }

    // ---- 인벤토리 ----
    void afterCargoChange(Inventory inv) {
        if (inv.getHolder() instanceof CargoHolder h) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                Car c = cars.get(h.carId);
                if (c != null) {
                    c.saveCargo();
                    c.updateCrates();
                }
            });
        } else if (inv.getHolder() instanceof FuelHolder h) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                Car c = cars.get(h.carId);
                if (c != null) c.saveState();
            });
        }
    }

    @EventHandler
    public void onInvClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (top.getHolder() instanceof FuelHolder) handleFuelClick(e, top);
        afterCargoChange(top);
    }

    void handleFuelClick(InventoryClickEvent e, Inventory top) {
        InventoryAction act = e.getAction();
        if (act == InventoryAction.COLLECT_TO_CURSOR || act == InventoryAction.CLONE_STACK) {
            e.setCancelled(true);
            return;
        }
        Inventory clicked = e.getClickedInventory();
        if (clicked == null) return;
        if (clicked.equals(top)) {
            if (e.getRawSlot() != 1) {
                e.setCancelled(true);
                return;
            }
            if (e.getClick() == ClickType.NUMBER_KEY) {
                ItemStack hb = e.getWhoClicked().getInventory().getItem(e.getHotbarButton());
                if (hb != null && !hb.getType().isAir() && !isFuel(hb)) e.setCancelled(true);
                return;
            }
            if (e.getClick() == ClickType.SWAP_OFFHAND) {
                ItemStack off = e.getWhoClicked().getInventory().getItemInOffHand();
                if (!off.getType().isAir() && !isFuel(off)) e.setCancelled(true);
                return;
            }
            ItemStack cur = e.getCursor();
            boolean placing = act == InventoryAction.PLACE_ALL || act == InventoryAction.PLACE_ONE
                    || act == InventoryAction.PLACE_SOME || act == InventoryAction.SWAP_WITH_CURSOR;
            if (placing && !cur.getType().isAir() && !isFuel(cur)) e.setCancelled(true);
        } else if (act == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
            e.setCancelled(true);
            ItemStack cur = e.getCurrentItem();
            if (cur == null || !isFuel(cur)) return;
            ItemStack slot = top.getItem(1);
            if (slot == null || slot.getType().isAir()) {
                top.setItem(1, cur.clone());
                e.setCurrentItem(null);
            } else if (slot.isSimilar(cur)) {
                int space = slot.getMaxStackSize() - slot.getAmount();
                int mv = Math.min(space, cur.getAmount());
                if (mv > 0) {
                    slot.setAmount(slot.getAmount() + mv);
                    cur.setAmount(cur.getAmount() - mv);
                    e.setCurrentItem(cur.getAmount() <= 0 ? null : cur);
                }
            }
        }
    }

    @EventHandler
    public void onInvDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (top.getHolder() instanceof FuelHolder) {
            for (int raw : e.getRawSlots()) {
                if (raw < top.getSize() && (raw != 1 || !isFuel(e.getOldCursor()))) {
                    e.setCancelled(true);
                    return;
                }
            }
        }
        afterCargoChange(top);
    }

    @EventHandler
    public void onInvClose(InventoryCloseEvent e) {
        Inventory inv = e.getInventory();
        if (inv.getHolder() instanceof CargoHolder h) {
            Car c = cars.get(h.carId);
            if (c != null) {
                c.saveCargo();
                c.updateCrates();
            }
        } else if (inv.getHolder() instanceof FuelHolder h) {
            Car c = cars.get(h.carId);
            if (c != null) c.saveState();
        }
    }

    // ---- 청크 로드/언로드 ----
    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) {
            if (en instanceof Interaction hb) {
                if (isTileHit(hb)) {
                    Bukkit.getScheduler().runTask(plugin, () -> tryRegisterTile(hb));
                } else if ("hull".equals(role(en))) {
                    Bukkit.getScheduler().runTask(plugin, () -> tryRegister(hb, 0));
                }
            }
        }
    }

    @EventHandler
    public void onEntitiesUnload(EntitiesUnloadEvent e) {
        for (Entity en : e.getEntities()) {
            if (!(en instanceof Interaction)) continue;
            if (isTileHit(en)) {
                int[] v = en.getPersistentDataContainer().get(K_TILE, PersistentDataType.INTEGER_ARRAY);
                if (v != null) tiles.remove(tileKey(en.getWorld(), v[0], v[1]));
            } else if ("hull".equals(role(en))) {
                Car c = carOf(en);
                if (c != null) {
                    c.saveState();
                    cars.remove(c.id);
                }
            }
        }
    }

    // =====================================================================
    //  명령어
    // =====================================================================
    boolean command(CommandSender sender, String[] a) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("인게임에서만 사용할 수 있습니다.");
            return true;
        }
        if (a.length >= 1 && a[0].equalsIgnoreCase("give")) {
            if (a.length >= 2 && a[1].equalsIgnoreCase("track")) {
                String bed = defaultBed;
                if (a.length >= 3) {
                    Material m = Material.matchMaterial(a[2]);
                    if (m == null || !m.isBlock()) {
                        p.sendMessage("블럭 이름이 올바르지 않습니다. 예: /train give track stone_bricks 16");
                        return true;
                    }
                    bed = m.createBlockData().getAsString();
                }
                int n = 16;
                if (a.length >= 4) {
                    try {
                        n = Math.max(1, Math.min(64, Integer.parseInt(a[3])));
                    } catch (NumberFormatException ignored) {
                    }
                }
                p.getInventory().addItem(trackItem(bed, n));
                p.sendMessage("지급: 철로 x" + n);
                return true;
            }
            CarType t = a.length >= 2 ? types.get(a[1].toLowerCase()) : null;
            if (t == null) {
                p.sendMessage("종류: track [블럭] [개수], " + String.join(", ", types.keySet()));
                return true;
            }
            p.getInventory().addItem(carItem(t));
            p.sendMessage("지급: " + t.label());
            return true;
        }
        if (a.length >= 1 && a[0].equalsIgnoreCase("remove")) {
            Car best = null;
            double bd = 8 * 8;
            for (Car c : cars.values()) {
                if (c.world != p.getWorld()) continue;
                double d = c.origin().distanceSquared(p.getLocation());
                if (d < bd) {
                    bd = d;
                    best = c;
                }
            }
            if (best == null) {
                p.sendMessage("8칸 이내에 기차가 없습니다.");
                return true;
            }
            Location l = best.origin().add(0, 1, 0);
            for (Inventory inv : best.cargo) {
                for (ItemStack it : inv.getContents()) if (it != null && !it.getType().isAir()) l.getWorld().dropItemNaturally(l, it);
                inv.clear();
            }
            if (best.fuelInv != null) {
                for (ItemStack it : best.fuelInv.getContents()) if (it != null && !it.getType().isAir()) l.getWorld().dropItemNaturally(l, it);
                best.fuelInv.clear();
            }
            detach(best);
            best.remove();
            cars.remove(best.id);
            p.sendMessage("가장 가까운 기차 칸을 제거했습니다. (내용물은 바닥에 떨어집니다)");
            return true;
        }
        p.sendMessage("/train give track [블럭] [개수]  -  5x5 철로 (바닥 블럭 지정 가능)");
        p.sendMessage("/train give <loco|cargo|pass>  -  조종칸/화물칸/탑승칸");
        p.sendMessage("/train remove  -  가장 가까운 칸 제거(8칸 이내)");
        return true;
    }
}
